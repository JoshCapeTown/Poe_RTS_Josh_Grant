﻿using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Poe_Josh_Grant02
{
    class Building
    {
        // Instance variables
        protected int x;
        protected int y;
        protected int health;
        protected string team;
        protected string symbol;

        // Constructor
        public Building(int x, int y, int health, string team, string symbol)
        {
            this.x = x;
            this.y = y;
            this.health = health;
            this.team = team;
            this.symbol = symbol;
        }
        ~Building()
        {

        }
        public int X
        {
            get { return x; }
            set { x = value; }
        }

        public int Y
        {
            get { return y; }
            set { y = value; }
        }
        public int Health
        {
            get { return health; }
            set { health = value; }

        }
        public string Faction
        {
            get { return Faction; }
            set { Faction = value; }
        }
        public string Symbol
        {
            get { return symbol; }
            set { symbol = value; }
        }
        // ToString method
        public virtual string toString()
        {
            string output = "x : " + x + Environment.NewLine
                 + "y : " + y + Environment.NewLine
                 + "Health : " + Health + Environment.NewLine
                 + "Faction/Team : " + Faction + Environment.NewLine
                 + "Symbol : " + Symbol + Environment.NewLine;
            return output;
        }
        public virtual void save()
        {

        }
    }
}
