﻿using UnityEngine;
using System.Collections;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;
using System.IO;

namespace Poe_Josh_Grant02
{
    class FactoryBuilding : Building
    {

        public int unitsToProduce;
        public int gameTicksPerProduction;
        public int spawnPointX;
        public int spawnPointY;

        public FactoryBuilding(int x, int y, int health, string team, string symbol, int unitsToProduce, int gameTicksPerProduction, int spawnPointX, int spawnPointY)
            : base(x, y, health, team, symbol)
        {
            this.unitsToProduce = unitsToProduce;
            this.gameTicksPerProduction = gameTicksPerProduction;
            this.spawnPointX = spawnPointX;
            this.spawnPointY = spawnPointY;
        }

        public  bool isAlive()
        {
            if (health > 0)
                return true;
            else
                return false;
        }

        public Unit spawnNewUnit()
        {
            if (unitsToProduce > 0)
            {
                Random rnd = new Random();
                if (rnd.Next(0, 2) == 0)
                {
                    MeleeUnit mU = new MeleeUnit(spawnPointX, spawnPointY, 100, -1, true, 1, this.Faction, "M", "CLub");
                    unitsToProduce--;
                    return mU;
                }
                else
                {
                    RangedUnit rU = new RangedUnit(spawnPointX, spawnPointY, 100, -1, true, 5, this.Faction, "R", "Gun");
                    unitsToProduce--;
                    return rU;
                }
            }
            else
                return null;
        }

        public override void save()
        {
            FileStream outFile = null;
            StreamWriter writer = null;
            try
            {
                outFile = new FileStream(@"Files\FactoryBuilding.txt", FileMode.Append, FileAccess.Write);
                 writer = new StreamWriter(outFile);
                writer.WriteLine(x);
                writer.WriteLine(y);
                writer.WriteLine(health);
                writer.WriteLine(team);
                writer.WriteLine(symbol);
                writer.WriteLine(unitsToProduce);
                writer.WriteLine(gameTicksPerProduction);
                writer.WriteLine(spawnPointX);
                writer.WriteLine(spawnPointY);
                writer.Close();
                outFile.Close();
            }
            catch (IOException fe)
            {
                Console.WriteLine("IOException: " + fe.Message);
            }
            finally
            {
                if (outFile != null)
                    outFile.Close();
                if (writer != null)
                    writer.Close();
            }
        }
    }
}
