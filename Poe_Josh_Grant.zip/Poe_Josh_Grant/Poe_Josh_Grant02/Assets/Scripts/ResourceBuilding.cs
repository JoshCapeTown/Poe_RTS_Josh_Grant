﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;
using System.IO;

namespace Poe_Josh_Grant02
{
    class ResourceBuilding : Building
    {

        private string resourceType;
        private int resourcesPerTick;
        private int resourcesRemaining;
        public int unitsToProduce;
        public int gameTicksPerProduction;
        public int spawnPointX;
        public int spawnPointY;

        public string ResourceType
        {
            get
            {
                return resourceType;
            }
            set
            {
                resourceType = value;
            }
        }
        public ResourceBuilding(int x, int y, int health, string team, string symbol, string resourceType, int resourcesPerTick, int resourcesRemaining)
            : base(x, y, health, team, symbol)
        {
            this.resourceType = resourceType;
            this.resourcesPerTick = resourcesPerTick;
            this.resourcesRemaining = resourcesRemaining;

        }

        public  bool isAlive()
        {
            if (health > 0)
                return true;
            else
                return false;

        }
        public override string toString()
        {
            string output = base.toString()
                + "resourceType " + resourceType + Environment.NewLine
                + "resourcePerGameTick" + resourcesPerTick + Environment.NewLine
                + " resourcesReamining" + resourcesRemaining + Environment.NewLine;

            return output;
        }

        public override void save()
        {
            FileStream outFile = null;
            StreamWriter writer = null;
            try
            {
                outFile = new FileStream(@"Files\ResourceBuilding.txt", FileMode.Append, FileAccess.Write);
                 writer = new StreamWriter(outFile);
                writer.WriteLine(x);
                writer.WriteLine(y);
                writer.WriteLine(health);
                writer.WriteLine(team);
                writer.WriteLine(symbol);
                writer.WriteLine(resourceType);
                writer.WriteLine(resourcesPerTick);
                writer.WriteLine(resourcesRemaining);
                writer.Close();
                outFile.Close();
            }
            catch (IOException fe)
            {
                Console.WriteLine("IOException: " + fe.Message);
            }
            finally
            {
                if (outFile != null)
                    outFile.Close();
                if (writer != null)
                    writer.Close();
            }
        }
 
        // Method to generate resources and remove from remaining resources 
        public void generateResoruces()
        {
            if (resourcesRemaining >= 0)
                resourcesRemaining -= resourcesPerTick;
        }


    }
}
